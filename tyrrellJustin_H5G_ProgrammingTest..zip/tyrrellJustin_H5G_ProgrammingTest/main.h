// main.h
//
// Holds necessary #defines and function headers for utility and support functions
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#ifndef MAIN_H
#define MAIN_H

#include "DiceGame\DiceGame.h"

using namespace DiceGame;

#endif